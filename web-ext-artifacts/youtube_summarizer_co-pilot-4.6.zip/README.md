# youtube-summarizer-copilot
Simple Firefox extension to summarize youtube videos with gemini
